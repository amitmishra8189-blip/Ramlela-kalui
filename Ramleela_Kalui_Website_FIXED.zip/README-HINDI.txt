श्री रामलीला कमेटी कलूई वेबसाइट

इस फोल्डर में index.html और assets फोल्डर दोनों मौजूद होने चाहिए। assets में आपकी फोटो और रामलीला पोस्टर हैं।

मोबाइल से Netlify पर लाइव/अपडेट करने के चरण:
1. ZIP डाउनलोड करके फोन के File Manager में Extract करें।
2. Extract हुए Ramleela_Kalui_New_Website फोल्डर को खोलें।
3. जाँचें कि index.html और assets फोल्डर एक ही स्तर पर हैं।
4. https://app.netlify.com/ खोलकर उसी Netlify खाते में लॉगिन करें।
5. अपनी साइट delicate-bavarois-aea4ae खोलें।
6. Deploys टैब खोलें और manual deploy / upload deploy area चुनें।
7. Extract किया हुआ पूरा फोल्डर अपलोड करें (केवल index.html नहीं)।
8. Deploy published होने के बाद https://delicate-bavarois-aea4ae.netlify.app खोलें।

यदि Netlify मोबाइल पर folder upload न दे, तो ZIP को Extract करके Chrome में Desktop site चालू करें और Deploys पेज पर दोबारा कोशिश करें।
